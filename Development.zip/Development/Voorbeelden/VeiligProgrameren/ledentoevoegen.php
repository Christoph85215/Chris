<?php
require 'config.php';
session_start();

include("session_hijacking_functions.php");
before_every_protected_page();

require 'header.php';
if ($_SESSION['ID'] == 1) {

    $token2 = bin2hex(openssl_random_pseudo_bytes(32));
    $_SESSION['token2'] = $token2;


    ?>
  
<div class="container-fluid text-center">    
  <div class="row content">
    <div class="col-sm-9 text-left"> 
     <h1>Lid toevoegen</h1>
     <form method="post" action="ledentoevoegen_verwerk.php">
        <table>
            <tr>
                <td>Voornaam:</td>
                <td><input type="text" value="<?php echo $name;?>" name="voornaamveld"/></td>
                <span class="error"><?php echo $nameErr;?></span>
            </tr>
            <tr>
                <td>Achternaam:</td>
                <td><input type="text" value="<?php echo $name2;?>" name="achternaamveld"/></td>
                <span class="error"><?php echo $name2Err;?></span>
            </tr>
            <tr>
                <td>Geboortedatum:</td>
                <td><input type="date" value="<?php echo $date;?>" name="geboortedatumveld"/></td>
                <span class="error"><?php echo $dateErr;?></span>
            </tr>
            <tr>
                <td>Telefoon:</td>
                <td><input type="text" value="<?php echo $phone;?>" name="telefoonveld"/></td>
                <span class="error"><?php echo $phoneErr;?></span>
            </tr>
             <tr>
                <td>Email:</td>
                <td><input type="text" value="<?php echo $email;?>" name="emailveld"/></td>
                 <span class="error"><?php echo $emailErr;?></span>
            </tr>
            <tr>
                <td>Wachtwoord:</td>
                <td><input type="text" value="<?php echo $wachtwoord;?>" name="wachtwoordveld"/></td>
                <span class="error"><?php echo $wachtwoordErr;?></span>
            </tr>
            <tr>
                <td>Team:</td>
                <td><select name ="teamveld">
                <?php 
                    $result = mysqli_query($mysqli, "SELECT * FROM VEIPRO_teams");
                    while ($row = mysqli_fetch_array($result))
                    {
                        echo "<option value='" . $row['teamID'] . "'>" .$row['teamID'] . "</option>";
                    }
                ?>
                </select></td>
            </tr>
             <tr>
                 <td>&nbsp</td>
                 <input type="hidden" name="csrf_token2" value="<?php echo $token2?>"/>
                <td><input type="submit" name="verstuurknop" value="VOEG TOE" class="btn-success"/></td>
            </tr>
        </table>
    </form>


    </div>
    <div class="col-sm-3 sidenav">
      <div class="well">
        <p><img src="img/sports-banner.png" class="img-responsive"/></p>
      </div>
      <div class="well">
        <p><img src="img/jersey-icon-set.png" class="img-responsive"/></p>
      </div>
    </div>
  </div>
</div>
    <?php

}else{
      header("location:index.php");
  }
?>

<?php
require 'footer.php';
?>


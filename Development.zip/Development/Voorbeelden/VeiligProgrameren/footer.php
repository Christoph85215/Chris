<footer class="container-fluid text-center">
    <p>Opgericht in 1991</p>
</footer>

</body>
</html>
-- phpMyAdmin SQL Dump
-- version 4.2.12deb2+deb8u2
-- http://www.phpmyadmin.net
--
-- Machine: localhost
-- Gegenereerd op: 19 jun 2018 om 13:20
-- Serverversie: 5.5.59-0+deb8u1
-- PHP-versie: 5.6.33-0+deb8u1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Databank: `dbVEIPROex`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `VEIPRO_admin`
--

CREATE TABLE IF NOT EXISTS `VEIPRO_admin` (
`adminID` int(11) NOT NULL,
  `Username` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `Password` varchar(80) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `VEIPRO_admin`
--

INSERT INTO `VEIPRO_admin` (`adminID`, `Username`, `Password`) VALUES
(1, 'admin', '#1Geheim');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `VEIPRO_leden`
--

CREATE TABLE IF NOT EXISTS `VEIPRO_leden` (
`lidID` int(11) NOT NULL,
  `Voornaam` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Achternaam` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Geboortedatum` date NOT NULL,
  `Telefoon` varchar(12) COLLATE utf8_unicode_ci NOT NULL,
  `Email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `Wachtwoord` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `Team` varchar(15) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `VEIPRO_leden`
--

INSERT INTO `VEIPRO_leden` (`lidID`, `Voornaam`, `Achternaam`, `Geboortedatum`, `Telefoon`, `Email`, `Wachtwoord`, `Team`) VALUES
(4, 'Voornaam', 'Achternaam', '1998-06-26', '010-1234567', 'mail@achternaam.nl', 'geheim', 'JO-17 1');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `VEIPRO_teams`
--

CREATE TABLE IF NOT EXISTS `VEIPRO_teams` (
  `teamID` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `teamNaam` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Poule` varchar(20) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Gegevens worden geëxporteerd voor tabel `VEIPRO_teams`
--

INSERT INTO `VEIPRO_teams` (`teamID`, `teamNaam`, `Poule`) VALUES
('JO-17 1', 'Jeugd onder 17, team1', 'West 3'),
('JO-17 2', 'Jeugd onder 17, team2', 'West 5'),
('JO-19 1', 'Jeugd onder 19, team 1', 'Zaterdag 2'),
('JO-19 2', 'Jeugd onder 19, team 2', 'Regionaal'),
('JO-15 1', 'Jeugd onder 15, team 1', 'Regionaal'),
('JO-15 2', 'Jeugd onder 15, team 2', 'Regionaal'),
('JO-15 3', 'Jeugd onder 15, team 3', 'Regionaal');

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `VEIPRO_admin`
--
ALTER TABLE `VEIPRO_admin`
 ADD PRIMARY KEY (`adminID`);

--
-- Indexen voor tabel `VEIPRO_leden`
--
ALTER TABLE `VEIPRO_leden`
 ADD PRIMARY KEY (`lidID`);

--
-- Indexen voor tabel `VEIPRO_teams`
--
ALTER TABLE `VEIPRO_teams`
 ADD PRIMARY KEY (`teamID`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `VEIPRO_admin`
--
ALTER TABLE `VEIPRO_admin`
MODIFY `adminID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT voor een tabel `VEIPRO_leden`
--
ALTER TABLE `VEIPRO_leden`
MODIFY `lidID` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

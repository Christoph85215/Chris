<?php
require 'config.php';
session_start();

//include("session_hijacking_functions.php");
//after_successful_logout();
//$messagetimeout = $_GET['msmt'];
//$messageinvalid = $_GET['msmi'];

$token = bin2hex(openssl_random_pseudo_bytes(32));
$_SESSION['token'] = $token;

//echo $token;

require 'header.php';
?>

  
<div class="container-fluid text-center">    
  <div class="row content">
    <div class="col-sm-9 text-left"> 
     <h1>INLOG</h1>
     <form method="post" action="inlog_verwerk.php">
<!--         --><?php //if($messagetimeout!="") { ?>
<!--             <div class="message">--><?php //echo $messagetimeout; ?><!--</div>-->
<!--         --><?php //} ?>
<!--         --><?php //if($messageinvalid!="") { ?>
<!--             <div class="message">--><?php //echo $messageinvalid; ?><!--</div>-->
<!--         --><?php //} ?>
        <table>
            <tr>
                <td>Gebruikersnaam:</td>
                <td><input type="text" name="name" value="<?php echo $name;?>">
                </td><span class="error"><?php echo $nameErr;?></span>
            </tr>
            <tr>
                <td>Wachtwoord:</td>
                <td><input type="text" name="wachtwoordveld" value="<?php echo $wachtwoord;?>"></td>
                </td><span class="error"><?php echo $wachtwoordErr;?></span>
            </tr>
             <tr>
                 <td>&nbsp</td>
                 <input type="hidden" name="csrf_token" value="<?php echo $token?>"/>
                 <td><input type="submit" name="verstuurknop" value="LOG IN" class="btn-success"/></td>
            </tr>
        </table>
    </form>


    </div>


    <div class="col-sm-3 sidenav">
      <div class="well">
        <p><img src="img/sports-banner.png" class="img-responsive"/></p>
      </div>
      <div class="well">
        <p><img src="img/jersey-icon-set.png" class="img-responsive"/></p>
      </div>
    </div>
  </div>
</div>


<?php
require 'footer.php';
?>

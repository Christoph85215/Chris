<?php
require 'config.php';
session_start();



ini_set("display_errors", 1);

ini_set("error_reporting", E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED);

$name = $wachtwoord = "";
$nameErr = $wachtwoordErr = "";
//echo $_SESSION["token"];

if (isset($_POST['verstuurknop'])) {
    //echo "chekck";
    if (isset($_SESSION["token"]) && $_SESSION["token"] == $_POST["csrf_token"]) {
        //echo "Token is OK";
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            if (empty($_POST["name"])) {
                $nameErr = "* Name is required";
            } else {
                $name = test_input($_POST["name"]);
                // check if name only contains letters and whitespace
                if (!preg_match("/^[a-zA-Z-' ]*$/", $name)) {
                    $nameErr = "* Only letters and white space allowed";
                } else {
                    if (empty($_POST["wachtwoordveld"])) {
                        $wachtwoordErr = "* Wachtwoordveld is required";
                    } else {
                        $wachtwoord = test_input($_POST["wachtwoordveld"]);
                        // check if name only contains letters and whitespace
                        if (!preg_match('/^(?=.*\d)(?=.*[A-Za-z])[0-9A-Za-z!@#$%]{8,12}$/', $wachtwoord)) {
                            $wachtwoordErr = "* Wachtwoord moet minimaal: 1 cijfer, 1 letter, 1 van deze tekens(!@#$%) en er moeten 4-12 tekens zijn.";
                        } else {
                            include("session_hijacking_functions.php");
                            //Maak de query
                            $opdracht = "SELECT * FROM VEIPRO_leden WHERE Voornaam = '$name' AND Wachtwoord = '$wachtwoord'";
                            //Voer de query uit en vang het resultaat op
                            $resultaat = mysqli_query($mysqli, $opdracht);

                            //Controleer of het resultaat een rij (user) heeft opgeleverd
                            if (mysqli_num_rows($resultaat) > 0) {
                                after_successful_login();
                                //Haal de user uit het resutaat
                                $user = mysqli_fetch_array($resultaat);
                                $_SESSION['voornaam'] = $user['Voornaam'];
                                $_SESSION['ID'] = $user['lidID'];
                                //Geef een melding
                                echo "<script language='javascript'>alert('Hallo $name, u bent ingelogd!');window.location = 'ledenuitlezen.php';</script>";
//                                         echo "<br><p>Hallo $name, u bent ingelogd!</p>";
//                                         echo $_SESSION['lidID'];
                            } else {
                                //Maak de query
                                $opdracht = "SELECT * FROM VEIPRO_admin WHERE Username = '$name' AND Password = '$wachtwoord'";
                                //Voer de query uit en vang het resultaat op
                                $resultaat = mysqli_query($mysqli, $opdracht);

                                //Controleer of het resultaat een rij (user) heeft opgeleverd
                                if (mysqli_num_rows($resultaat) > 0) {
                                    after_successful_login();
                                    //Haal de user uit het resutaat
                                    $user = mysqli_fetch_array($resultaat);
                                    $_SESSION['voornaam'] = $user['Username'];
                                    $_SESSION['ID'] = $user['adminID'];
                                    //Geef een melding
                                    echo "<script language='javascript'>alert('Hallo $name, u bent ingelogd!');window.location = 'ledentoevoegen.php';</script>";
//                                         echo "<br><p>Hallo $name, u bent ingelogd!</p>";
//                                         echo $_SESSION['lidID'];
                                }else {
                                    echo "Naam of Wachtwoord klopt niet";
                                }
                            }
                        }
                    }
                }
            }
        }
    } else {
        echo "token klopt niet";
        //echo $_SESSION["token"];
    }

}
function test_input($data){
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

include "inlog.php";


?>
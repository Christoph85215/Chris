<?php
require 'config.php';
session_start();

include("session_hijacking_functions.php");
before_every_protected_page();

require 'header.php';

?>
  
<div class="container-fluid text-center">    
  <div class="row content">
    <div class="col-sm-9 text-left"> 
     <h1>Alle jeugdleden</h1>

<?php
  if (isset($_SESSION['voornaam'])){
      if ($_SESSION['ID'] == 1) {
?>
            <table class="table-striped">
                <tr>
                    <th>Voornaam</th>
                    <th>Achternaam</th>
                    <th>Geboortedatum</th>
                    <th>Telefoon</th>
                    <th>Email</th>
                    <th>Wachtwoord</th>
                    <th>Team</th>
                </tr>
                <?php


                $result = mysqli_query($mysqli, "SELECT * FROM VEIPRO_leden");
                while ($row = mysqli_fetch_array($result))
                {
                    echo "<tr>";
                    echo "<td>" . $row['Voornaam'] . "</td>";
                    echo "<td>" . $row['Achternaam'] . "</td>";
                    echo "<td>" . $row['Geboortedatum'] . "</td>";
                    echo "<td>" . $row['Telefoon'] . "</td>";
                    echo "<td>" . $row['Email'] . "</td>";
                    echo "<td>" . $row['Wachtwoord'] . "</td>";
                    echo "<td>" . $row['Team'] . "</td>";
                    echo "</tr>";
                }
                ?>
            </table>
            <?php
        } else {
        ?><table class="table-striped">
            <tr>
                <th>Voornaam</th>
                <th>Achternaam</th>
                <th>Team</th>
            </tr>
            <?php


            $result = mysqli_query($mysqli, "SELECT * FROM VEIPRO_leden");
            while ($row = mysqli_fetch_array($result))
            {
                echo "<tr>";
                echo "<td>" . $row['Voornaam'] . "</td>";
                echo "<td>" . $row['Achternaam'] . "</td>";
                echo "<td>" . $row['Team'] . "</td>";
                echo "</tr>";
            }
            ?>
        </table>
          <?php
      }
}else{
      header("location:inlog.php");
  }
?>


    </div>
      <div class="col-sm-3 sidenav">
          <div class="well">
              <p><img src="img/sports-banner.png" class="img-responsive"/></p>
          </div>
          <div class="well">
              <p><img src="img/jersey-icon-set.png" class="img-responsive"/></p>
          </div>
      </div>
  </div>
</div>

<?php
require 'footer.php';
?>

}
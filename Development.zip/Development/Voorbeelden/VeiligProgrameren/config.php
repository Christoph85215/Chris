
<?php
//database logingegevens
$db_hostname = '127.0.0.1'; //of '127.0.0.1'
$db_username = 'root';
$db_password = '';
$db_database = 'dbveiproex';

//maak de database-verbinding
$mysqli = mysqli_connect($db_hostname, $db_username, $db_password, $db_database);

//als de verbinding niet gemaakt kan worden: geef een foutmelding
if (!$mysqli) {
    echo "FOUT: geen connectie naar database. <br>";
    echo "Errno: " . mysqli_connect_error() . "<br>";
    echo "Error: " . mysqli_connect_error() . "<br>";
    exit;
}
//foutmelding zichbaar maken
//error_reporting(E_ALL);
//ini_set('display_errors','1');

?>

<?php
require 'config.php';
session_start();

require 'header.php';
?>

<div class="container-fluid text-center">
    <div class="row content">
        <div class="col-sm-9 text-left">
            <h1>Sportclub Rust Roest</h1>
            <p>Welkom</p>
            <p><blockquote>Als je het niet probeert heb je al verloren</blockquote></p>
            <hr>
            <h3>Zaterdag 7 juli </h3>
            <p>Toernooi voor jong en oud!<br/>
                meer info volgt...</p>
        </div>
        <div class="col-sm-3 sidenav">
            <div class="well">
                <p><img src="img/sports-banner.png" class="img-responsive"/></p>
            </div>
            <div class="well">
                <p><img src="img/jersey-icon-set.png" class="img-responsive"/></p>
            </div>
        </div>
    </div>
</div>


<?php
require 'footer.php';
?>

<?php

session_start();


// Functie om de sessie geforceerd te beëindigen
function end_session() {
	session_unset();
	session_destroy();
} 

// Komt het verzoek-IP overeen met de opgeslagen waarde?
function request_ip_matches_session() {
	// retourneer false als een van beide waarden niet is ingesteld
	if(!isset($_SESSION['ip']) || !isset($_SERVER['REMOTE_ADDR'])) {
		return false;
	}
	if($_SESSION['ip'] === $_SERVER['REMOTE_ADDR']) {
		return true;
	} else {
		return false;
	}
}

// Komt de user-agent van het verzoek overeen met de opgeslagen waarde?
function request_user_agent_matches_session() {
	// retourneer false als een van beide waarden niet is ingesteld
	if(!isset($_SESSION['user_agent']) || !isset($_SERVER['HTTP_USER_AGENT'])) {
		return false;
	}
	if($_SESSION['user_agent'] === $_SERVER['HTTP_USER_AGENT']) {
		return true;
	} else {
		return false;
	}
}

// Is er te veel tijd verstreken sinds de laatste login? LOG UIT
function last_login_is_recent() {
	$max_elapsed = 60 * 60 * 3; // 3 uur
	// return false als de waarde niet is ingesteld
	if(!isset($_SESSION['last_login'])) {
		return false;
	}
	if(($_SESSION['last_login'] + $max_elapsed) >= time()) {
		return true;
	} else {
		return false;
	}
}

// Moet de sessie als geldig worden beschouwd?
function is_session_valid() {
	$check_ip = true;
	$check_user_agent = true;
	$check_last_login = true;

	if($check_ip && !request_ip_matches_session()) {
		return false;
	}
	if($check_user_agent && !request_user_agent_matches_session()) {
		return false;
	}
	if($check_last_login && !last_login_is_recent()) {
		return false;
	}
	return true;
}

// Als de sessie niet geldig is, beëindig dan en stuur door naar de inlogpagina.
function confirm_session_is_valid() {
	if(!is_session_valid()) {
		end_session();
		header("Location: inlog.php?msmt=Login Session Ended. Please Login Again");
		exit;
	}
}


// Is de gebruiker al ingelogd?
function is_logged_in() {
	return (isset($_SESSION['logged_in']) && $_SESSION['logged_in']);
}

// Als de gebruiker niet is ingelogd, beëindig dan en stuur door naar de inlogpagina.
function confirm_user_logged_in() {
	if(!is_logged_in()) {
		end_session();
		header("Location: inlog.php?msmt=Login Session Ended. Please Login Again");
		exit;
	}
}


// Acties die moeten worden uitgevoerd na elke succesvolle login
function after_successful_login() {
	// Genereer de sessie-ID
	// Super belangrijk om te voorkomen "session hijacking/fixation".
	
	$_SESSION['logged_in'] = true;

	// Bewaar deze waarden in de sessie,
	// zelfs als controles niet zijn ingeschakeld
	$_SESSION['ip'] = $_SERVER['REMOTE_ADDR'];
	$_SESSION['user_agent'] = $_SERVER['HTTP_USER_AGENT'];
	$_SESSION['last_login'] = time();

}

// Acties die moeten worden uitgevoerd na elke succesvolle afmelding
function after_successful_logout() {
	$_SESSION['logged_in'] = false;
	end_session();
}

//Acties die moeten worden uitgevoerd 
//voordat toegang wordt verleend 
//tot een pagina met beperkte toegang.
function before_every_protected_page() {
	confirm_user_logged_in();
	confirm_session_is_valid();
}

?>

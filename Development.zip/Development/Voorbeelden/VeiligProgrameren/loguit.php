<?php

//Start de sessions
session_start();

include("session_hijacking_functions.php");
//Verwijder alle sessions
end_session();
before_every_protected_page();

?>
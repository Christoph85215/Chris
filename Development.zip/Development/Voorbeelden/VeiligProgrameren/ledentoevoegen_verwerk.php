<?php
require 'config.php';
session_start();

ini_set("display_errors", 1);
ini_set("error_reporting", E_ALL & ~E_NOTICE & ~E_STRICT & ~E_DEPRECATED);

//include("session_hijacking_functions.php");
//before_every_protected_page();

$nameErr = $name2Err = $dateErr = $phoneErr = $emailErr = $wachtwoordErr = "";
$name = $name2 = $date = $phone = $email = $wachtwoord = "";

if (isset($_SESSION["token2"]) && $_SESSION["token2"] == $_POST["csrf_token2"]) {
    //echo "token is ok";

    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        //Voornaam
        if (empty($_POST["voornaamveld"])) {
            $nameErr = "* Name is required";
        } else {
            $name = test_input($_POST["voornaamveld"]);
            // check if name only contains letters and whitespace
            if (!preg_match("/^[a-zA-Z-' ]*$/",$name)) {
                $nameErr = "* Only letters and white space allowed";
            }else{
                //Achternaam
                if (empty($_POST["achternaamveld"])) {
                    $name2Err = "* Name is required";
                } else {
                    $name2 = test_input($_POST["achternaamveld"]);
                    // check if name only contains letters and whitespace
                    if (!preg_match("/^[a-zA-Z-' ]*$/", $name2)) {
                        $name2Err = "* Only letters and white space allowed";
                    } else {
                        //Check date
                        if (empty($_POST["geboortedatumveld"])) {
                            $dateErr = "* date is required";
                        } else {
                            $dateck="12-09-2012";
                            $date = test_input($_POST["geboortedatumveld"]);

                            //Check Phone
                            if (empty($_POST["telefoonveld"])) {
                                $phoneErr = "* Phone is required";
                            } else {
                                //$phonech = '00-0000-0000';
                                $phone = test_input($_POST["telefoonveld"]);
                                // check if name only contains letters and whitespace
                                if (!preg_match('/^[0-9]{2}[0-9]{4}[0-9]{4}$/', $phone)) {
                                    $phoneErr = "* Invalid telefone number Voorbeeld:00 00000000";
                                }else{
                                    //Check Email
                                    if (empty($_POST["emailveld"])) {
                                        $emailErr = "* Email is required";
                                    } else {
                                        $email = test_input($_POST["emailveld"]);
                                        // check if e-mail address is well-formed
                                        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                                            $emailErr = "* Invalid email format";
                                        } else{
                                            //check password
                                            if (empty($_POST["wachtwoordveld"])) {
                                                $wachtwoordErr = "* Wachtwoordveld is required";
                                            } else {
                                                $wachtwoord = test_input($_POST["wachtwoordveld"]);
                                                // check if name only contains letters and whitespace
                                                if (!preg_match('/^(?=.*\d)(?=.*[A-Za-z])[0-9A-Za-z!@#$%]{4,12}$/', $wachtwoord)) {
                                                    $wachtwoordErr = "* Wachtwoord moet minimaal: 1 cijfer, 1 letter en er moeten 4-12 tekens zijn.";
                                                } else {

                                                    $team           = $_POST['teamveld'];

                                                    $sql = "INSERT INTO VEIPRO_leden (lidID, Voornaam, Achternaam, Geboortedatum, Telefoon, Email, Wachtwoord, Team) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

                                                    //check of je query  in orde is en 'prepare' deze
                                                    if ($stmt = $mysqli->prepare($sql)) {
                                                        $id = uuidv4();
                                                        //verbind de vraagtekens met variabelen
                                                        $stmt->bind_param('ssssisss', $id, $name, $name2, $date, $phone, $email, $wachtwoord, $team);


                                                        //Voeg de variabelen toe
                                                        if ($stmt->execute()) {
                                                            echo "<script language='javascript'>alert('Form is toegevoegd');window.location = 'ledenuitlezen.php';</script>";
                                                        } else {
                                                            echo 'Het uitvoeren van de query is mislukt:' . $stmt->error . '<br> in query: ' . $sql;
                                                        }
                                                    } else {
                                                        echo "Er zit een fout in de query:" . $mysqli->error . "<br>";
                                                    }
                                                    $stmt->close();

                                                }
                                            }
                                        }

                                    }
                                }

                            }
                        }

                    }
                }
            }

        }
    }
}else{
    echo "token klopt niet";
}

function uuidv4(){
    $data = openssl_random_pseudo_bytes(16);

    $data[6] = chr(ord($data[6]) & 0x0f | 0x40);
    $data[8] = chr(ord($data[8]) & 0x3f | 0x80);

    return vsprintf('%s%s-%s-%s-%s-%s%s%s', str_split(bin2hex($data), 4));
}

function test_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

include "ledentoevoegen.php";
?>
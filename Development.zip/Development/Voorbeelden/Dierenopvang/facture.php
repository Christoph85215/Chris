<?php
$page = "Facture";
require 'PHP/config.php';
require 'PHP/head.php';
require 'PHP/sessionCheck.php';


//$dierID = $_GET['id'];
$klantID = $_GET['t_id'];

$query = "SELECT * FROM `Klanten` WHERE klantID = '".$klantID."'";
$resultaat = mysqli_query($verbinding, $query);
$rij = mysqli_fetch_array($resultaat);

$query2 = "SELECT * FROM `facture` WHERE klantID = '".$klantID."'";
$resultaat2 = mysqli_query($verbinding, $query2);
$rij2 = mysqli_fetch_array($resultaat2);

$dierenID = $rij2['dierID'];

$query3 = "SELECT * FROM `dieren` WHERE dierID = '".$dierenID."'";
$resultaat3 = mysqli_query($verbinding, $query3);
$rij3 = mysqli_fetch_array($resultaat3);



?>

    <!--    Style is in klant.css   -->

<button class="printpage" onclick="window.print()">Print</button>

<div class="container">
    <div class="pdfKlantDetail">
        <img class="logoFoto" src="IPP/LOGO.png">
        <ul class="info1">
            <li>Naam: <?php echo $rij['klantVoornaam']?></li>
            <li>Telefone: <?php echo $rij['klantTelefoon']?></li>
            <li>Adres: <?php echo $rij['klantAdres']?></li>
            <li>E-mail: <?php echo $rij['klantEmail']?></li>
        </ul>
        <ul class="info2">
            <li>Achretnaam: <?php echo $rij['klantAchternaam']?></li>
            <li>Stad: <?php echo $rij['klantStad']?></li>
        </ul>
        <ul class="info3">
            <li>Document Nummer(id): <?php echo $rij['klantID'];?>
            </li>
            <li>
                Prijs: <?php echo $rij2['prijs']?>
            </li>
        </ul>
    </div>
</div>
<div class="container">
    <div class="pdfDierenDetail">
        <img class="hondFoto" src="<?php echo $rij3['foto']?>">
        <ul class="hondinfo1">
            <li>Naam: <?php echo $rij3['dierNaam']?></li>
            <li>Soort: <?php echo $rij3['dierSoort']?></li>
            <li>Kleur: <?php echo $rij3['kleur']?></li>
            <li>Geslacht: <?php echo $rij3['geslacht']?></li>
            <li>Gecastreert: <?php echo $rij3['gecastreert']?></li>
            <li>Status: <?php echo $rij3['status']?></li>
        </ul>
        <ul class="hondinfo2">
            <li>Ras: <?php echo $rij3['ras']?></li>
            <li>Geboortedatum: <?php echo $rij3['geboortedatum']?></li>
            <li>Datum Binnen: <?php echo $rij3['datumBinnen']?></li>
            <li>Ingeënt: <?php echo $rij3['geent']?></li>
            <li>ID: <?php echo $rij3['dierID']?></li>
        </ul>
    </div>
</div>


<?php
require 'PHP/foot.php';
?>


<?php
$page = "Dieren";
require 'PHP/config.php';
require 'PHP/head.php';
require 'PHP/sessionCheck.php';
?>


<?php
//Maak de query

$id = $_GET['id'];

$query = "SELECT * FROM Klanten";

//Vang het resultaat van de query op in 'resultaat'
$resultaat = mysqli_query($verbinding, $query);

//Als het resultaat uit 0 rijen bestaat:
if (mysqli_num_rows($resultaat) == 0)
{
    echo "<p>Er zijn geen resultaten gevonden.</p>";
}
//Als er wel rijen zijn gevonden:
else{
//Maak een tabel (BUITEN DE WHILE_LUS!)
?>
<table style='width: 800px' class='table klant table-striped table-dark'>
    <thead>
    <tr>
        <th scope='col'>Naam</th>
        <th scope='col'>Achternaam</th>
        <th scope='col'>Adres</th>
        <th scope='col'>Koppeling maken</th>
    </tr>
    </thead>

    <tbody>
    <?php
    //Via een while worden alle rijen uitgelezen en getoond
    while ($rij = mysqli_fetch_array($resultaat))
    {
        echo "<tr>";
        echo "<th scope='row'>" . $rij['klantVoornaam'] . "</td>";
        echo "<th>" . $rij['klantAchternaam'] . "</th>";
        echo "<th>" . $rij['klantAdres'] . "</th>";
        echo "<th> <a href='PHP/koppeling_verwerk.php?t_id=". $rij['klantID']."&id=" .$id. "'>Koppeling maken</a></th>";
        echo "</tr>";
    }
    echo "</tbody>";
    echo "</table>";
    }

    ?>


    <?php
    require 'PHP/foot.php';
    ?>

<?php
$page = "Prijs";
require 'config.php';
require 'head.php';
require 'sessionCheck.php';
?>


<?php

$dierID = $_GET['id'];
$klantID = $_GET['t_id'];
$date = date("Y/m/d");
$prijs = $_POST['prijs'];


if (empty($prijs)){
    ?>
    <div class="container">
        <div class="formBox2">
            <div class="card2" style="height: 300px; top: 400px;">
                <h2>Prijs</h2>
                <form class="px-4 py-3" action="" method="post" enctype="multipart/form-data">
                    <div class="row mb-3">
                        <label for="prijs" class="col-sm-2 col-form-label">Prijs: </label>
                        <div class="col-sm-10">
                            <input type="number" name="prijs" class="form-control" id="prijs" placeholder="prijs" required>
                        </div>
                    </div>
                    <button type="submit" class="btn dtButton btn-primary" style="top: 180px;">Submit</button>
                </form>
            </div>
        </div>
    </div>
    <?php
}else{

    $query = "INSERT INTO facture (`factuurID`,`klantID`,`dierID`,`factuurDate`,`prijs`) 
VALUES (NULL,'$klantID','$dierID','$date','$prijs')";

    $query1 = "UPDATE dieren SET status='opgehaald' WHERE dierID=".$dierID.";";

    if (mysqli_query($verbinding, $query)) {
        if (mysqli_query($verbinding, $query1)){
            header("location: ../facture.php?t_id=$klantID&id=$dierID");
        }else {
            ?>
            <div class="alert alert-warning" style="top: 200px" role="alert">
                <p>Fout bij toevoegen, iets ging mis...</p><br>

                <?php
                echo mysqli_error($verbinding);
                var_dump($query1);
                ?>
            </div>
            <?php
        }
    } else {
        ?>
        <div class="alert alert-warning" role="alert">
            <p>Fout bij toevoegen, iets ging mis...</p><br>

            <?php
            echo mysqli_error($verbinding);
            var_dump($query);
            ?>
        </div>
        <?php
    }


}

?>

<?php
require 'foot.php';
?>

<?php
require 'config.php';
$voornaam = $_POST['newklantVoornaam'];
$achternaam = $_POST['newklantAchternaam'];
$adres = $_POST['newklantAdres'];
$stad = $_POST['newklantStad'];
$telefoon = $_POST['newklantTelefoon'];
$email = $_POST['newklantEmail'];
$docnr = $_POST['newklantDocnr'];


$query = "INSERT INTO Klanten (klantID, klantVoornaam, klantAchternaam, klantAdres, klantStad, klantTelefoon, klantEmail, klantDocNr) 
            VALUES (NULL ,'$voornaam' ,'$achternaam' ,'$adres' ,'$stad' ,'$telefoon' ,'$email' ,'$docnr' )";

if (mysqli_query($verbinding, $query)){
    echo "<p>klant $voornaam $achternaam is toegevoegd!</p>";
    header("location: ../klant.php");
}
else{
    ?>
    <div class="alert alert-warning" role="alert">
        <p>Fout bij toevoegen, iets ging mis...</p><br>

        <?php
        echo mysqli_error($verbinding);
        ?>
    </div>
    <?php
}
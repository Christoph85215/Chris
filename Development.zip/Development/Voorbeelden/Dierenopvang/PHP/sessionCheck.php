<?php
if (!isset($_SESSION['email'])){
    //Stuur de grbruiker direct terug naar 'inlog.php'
    header("location:index.php");
}
?>
<?php
require 'config.php';
$email = $_POST['newuserEmail'];
$voornaam = $_POST['newuserVoornaam'];
$achternaam = $_POST['newuserAchternaam'];
$gebruikersnaam = $_POST['newuserGebruikersnaam'];
$wachtwoord = md5($_POST['newuserWachtwoord']);

$query = "INSERT INTO medewerkers (medewerkerID, voornaam, achternaam, email, gebruikersnaam, password, role) 
            VALUES (NULL ,'$voornaam' ,'$achternaam' ,'$email' ,'$gebruikersnaam' ,'$wachtwoord' ,'medewerker' )";

if (mysqli_query($verbinding, $query)){
    echo "<p>Medewerker $voornaam $achternaam is toegevoegd!</p>";
//    header("location: profile.php");
}
else{
    ?>
    <div class="alert alert-warning" role="alert">
        <p>Fout bij toevoegen, iets ging mis...</p><br>

        <?php
        echo mysqli_error($verbinding);
        ?>
    </div>
    <?php
}
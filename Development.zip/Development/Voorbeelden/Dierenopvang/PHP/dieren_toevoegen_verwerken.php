<?php

require 'config.php';

$filename = $_FILES['file']['name'];
$target_dir = "img/";
if ($filename !=''){
    $target_file = $target_dir.basename($_FILES['file']['name']);

    //File extension
    $extension = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));

    //Valid file extension
    $extension_arr = array("jpg","jpeg","png","gif");

    //Check extension
    if(in_array($extension,$extension_arr)){
        //Convert to base64
        $image_base64 = base64_encode(file_get_contents($_FILES['file']['tmp_name']));
        $image = "data::image/".$extension. ";base64,".$image_base64;

        //Store image to 'upload' folder
        if(move_uploaded_file($_FILES['file']['tmp_name'], $target_file)) {

            $soort = $_POST['Soort'];
            $naam = $_POST['Naam'];
            $ras = $_POST['Ras'];
            $kleur = $_POST['Kleur'];
            $geboortedatum = $_POST['Geboortedatum'];
            $datumBinnen = $_POST['DatumBinnen'];
            $geslacht = $_POST['Geslacht'];

            $gecastreert = $_POST['Gecastreert'];

            $geent = $_POST['Geent'];

            $status = $_POST['Status'];

            $medische = $_POST['Medische'];
            $omschrijving = $_POST['Omschrijving'];


            $query = "INSERT INTO dieren (`dierID`,`dierNaam`,`dierSoort`,`ras`,`kleur`,`geboortedatum`,`datumBinnen`,`geslacht`,`gecastreert`,`omschrijving`,`medischeGegevens`,`geent`,`foto`,`status`) 
                        VALUES (NULL,'$naam','$soort','$ras','$kleur','$geboortedatum','$datumBinnen','$geslacht','$gecastreert','$omschrijving','$medische','$geent','$image','$status')";

            if (mysqli_query($verbinding, $query)) {
                echo "<p>Dier $soort, $ras is toegevoegd!</p>";
                header("location: ../dieren.php");
            } else {
                ?>
                <div class="alert alert-warning" role="alert">
                    <p>Fout bij toevoegen, iets ging mis...</p><br>

                    <?php
                    echo mysqli_error($verbinding);
                    var_dump($query);
                    ?>
                </div>
                <?php
            }
        }else{
                echo "je image was te groot";
            }
    }else{
        echo "er was een error";
    }
}else {
    echo "you cannot upload these images";
    }
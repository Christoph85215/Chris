<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <!-- CSS -->
    <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/klant.css">
    <link rel="stylesheet" href="../css/dieren.css">
    <link rel="stylesheet" href="../css/headstyle.css">

    <title>Dieropvang - <?php echo $page; ?></title>
</head>
<body>

<?php
    session_start();
    if (isset($_SESSION['email'])) {
        ?>
        <!-- Zoeken Bar -->
        <div class="zoekenBar">
            <form action="zoeken.php" method="post">
                <div class="input-group mb-3">
                    <input type="text" name="search" class="form-control" placeholder="Hier je zoek opdracht">
                    <input type="submit" value="Zoek" class="btn btn-outline-secondary">
                </div>
            </form>
        </div>

        <!------Zijkant NavBar------>
        <input type="checkbox" id="check">
        <label id="icone" for="check">
            <svg xmlns="http://www.w3.org/2000/svg" width="90" height="65" fill="currentColor" class="bi bi-list"
                 viewBox="0 0 16 16">
                <path fill-rule="evenodd"
                      d="M2.5 11.5A.5.5 0 0 1 3 11h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4A.5.5 0 0 1 3 7h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4A.5.5 0 0 1 3 3h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5z"/>
            </svg>
        </label>

        <!-- Bar Links -->
        <div class="barra">
            <nav>
                <a href="dieren.php">
                    <div class="link">Dieren</div>
                </a>
                <a href="../dieren_toevoegen.php">
                    <div class="link">Dieren Toevoegen</div>
                </a>
                <a href="klant.php">
                    <div class="link">Klant</div>
                </a>
                <a href="newKlant.php">
                    <div class="link">Klant Toevoegen</div>
                </a>
                <a href="PHP/uitlog.php">
                    <div class="link">uitlog</div>
                </a>
            </nav>
        </div>
        <!-- Bar Links End-->
        <!------Zijkant NavBar End------>
        <?php
    }

    else{

    }
?>


<?php
$page = "Koppeling";
require 'PHP/config.php';
require 'PHP/head.php';
require 'PHP/sessionCheck.php';

$id = $_GET['id'];

$query = "SELECT * FROM `dieren` WHERE dierID = '".$id."'";
$resultaat = mysqli_query($verbinding, $query);
$rij = mysqli_fetch_array($resultaat);

$query2 = "SELECT * FROM `facture` WHERE dierID = '".$id."'";
$resultaat2 = mysqli_query($verbinding, $query2);
$rij2 = mysqli_fetch_array($resultaat2);

$klantID = $rij2['klantID'];

?>


<div class="container">
    <div class="dierenDetail">
        <img class="hondFoto" src="<?php echo $rij['foto']?>">

        <?php
        if ($rij['status'] == 'opvang'){
            ?><button class="KoppelingButton"><a href='koppeling.php?id=<?php echo $rij['dierID']?>'>Koppeling</a></button><?php
        }if ($rij['status'] == 'opgehaald') {
            ?><button class="KoppelingButton"><a href='facture.php?t_id=<?php echo $klantID?>'>pdf</a></button><?php
        }
        ?>
        <ul class="hondinfo1">
            <li>Naam: <?php echo $rij['dierNaam']?></li>
            <li>Soort: <?php echo $rij['dierSoort']?></li>
            <li>Kleur: <?php echo $rij['kleur']?></li>
            <li>Geslacht: <?php echo $rij['geslacht']?></li>
            <li>Gecastreert: <?php echo $rij['gecastreert']?></li>
            <li>Status: <?php echo $rij['status']?></li>
        </ul>
        <ul class="hondinfo2">
            <li>Ras: <?php echo $rij['ras']?></li>
            <li>Geboortedatum: <?php echo $rij['geboortedatum']?></li>
            <li>Datum Binnen: <?php echo $rij['datumBinnen']?></li>
            <li>Ingeënt: <?php echo $rij['geent']?></li>
            <li>ID: <?php echo $rij['dierID']?></li>
        </ul>
        <ul class="hondinfo3">
            <li>Medische Gegevens:
                <button class="btn MGButton btn-primary" type="button" data-bs-toggle="collapse" data-bs-target="#collapse1" aria-expanded="false" aria-controls="collapseExample">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-down" viewBox="0 0 16 16">
                        <path fill-rule="evenodd" d="M8 1a.5.5 0 0 1 .5.5v11.793l3.146-3.147a.5.5 0 0 1 .708.708l-4 4a.5.5 0 0 1-.708 0l-4-4a.5.5 0 0 1 .708-.708L7.5 13.293V1.5A.5.5 0 0 1 8 1z"/>
                    </svg>
                </button>
            </li>
            <br>
            <li>
                <div class="collapse" id="collapse1">
                    <div class="card MedInfo card-body">
                        <?php echo $rij['medischeGegevens']?>
                    </div>
                </div>
            </li>

        </ul>

        <ul class="hondinfo4">
            <li>Omschrijving:
                <button class="btn OButton btn-primary" type="button" data-bs-toggle="collapse" data-bs-target="#collapse2" aria-expanded="false" aria-controls="collapseExample">
                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-arrow-down" viewBox="0 0 16 16">
                        <path fill-rule="evenodd" d="M8 1a.5.5 0 0 1 .5.5v11.793l3.146-3.147a.5.5 0 0 1 .708.708l-4 4a.5.5 0 0 1-.708 0l-4-4a.5.5 0 0 1 .708-.708L7.5 13.293V1.5A.5.5 0 0 1 8 1z"/>
                    </svg>
                </button>
            </li>
            <br>
            <li>
                <div class="collapse" id="collapse2">
                    <div class="card MedInfo card-body">
                        <?php echo $rij['omschrijving']?>
                    </div>
                </div>
            </li>
        </ul>

    </div>
</div>


<?php
require 'PHP/foot.php';
?>

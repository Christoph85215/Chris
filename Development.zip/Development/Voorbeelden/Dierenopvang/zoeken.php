<?php
$page = "Zoeken";
require 'PHP/config.php';
require 'PHP/head.php';
require 'PHP/sessionCheck.php';
?>
    <table style='width: 800px' class='table dieren table-striped table-dark'>
        <thead>
        <tr>
            <th scope='col'>Foto</th>
            <th scope='col'>Dier Soort</th>
            <th scope='col'>Ras</th>
            <th scope='col'>Detail</th>
        </tr>
        </thead>
        <tbody>
<?php
$search = $_POST['search'];
$sql = "select * from dieren where dierSoort like '%$search%' OR ras  like '%$search%'";

$result = $verbinding->query($sql);

if (mysqli_num_rows($result) == 0){
    echo "0 records";
} else {
    while($row = $result->fetch_assoc() ){
        echo "<tr>";
        echo "<th scope='row'><img src='" . $row['foto'] . "' width='100' height='65'></td>";
        echo "<th>" . $row['dierSoort'] . "</th>";
        echo "<th>" . $row['ras'] . "</th>";
        echo "<th> <a href='dieren_detail.php?id=".$row['dierID']."'>detail</a></th>";
        echo "</tr>";
    }
    echo "</tbody>";
    echo "</table>";
}
?>
<?php
require 'PHP/foot.php';
?>


<?php
$page = "Dieren";
require 'PHP/config.php';
require 'PHP/head.php';
require 'PHP/sessionCheck.php';
?>


<?php
//Maak de query
$query = "SELECT * FROM Klanten";

//Vang het resultaat van de query op in 'resultaat'
$resultaat = mysqli_query($verbinding, $query);

//Als het resultaat uit 0 rijen bestaat:
if (mysqli_num_rows($resultaat) == 0)
{
    echo "<p>Er zijn geen resultaten gevonden.</p>";
}
//Als er wel rijen zijn gevonden:
else{
//Maak een tabel (BUITEN DE WHILE_LUS!)
?>
<div class="container">
    <div class="row">
        <div class="card">
            <div class="card-body">
                <form action="zoeken.php" method="post">
                    <div class="input-group mb-3">
                        <input type="text" name="search" class="form-control" placeholder="Hier je zoek opdracht">
                        <input type="submit" value="Zoek" class="btn btn-outline-secondary">
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="row">
        <table style='width: 800px' class='table klant table-striped table-dark'>
            <thead>
            <tr>
                <th scope='col'>Naam</th>
                <th scope='col'>Achternaam</th>
                <th scope='col'>Adres</th>
                <th scope='col'>Detail</th>
            </tr>
            </thead>

            <tbody>
            <?php
            //Via een while worden alle rijen uitgelezen en getoond
            while ($rij = mysqli_fetch_array($resultaat))
            {
                echo "<tr>";
                echo "<th scope='row'>" . $rij['klantVoornaam'] . "</td>";
                echo "<th>" . $rij['klantAchternaam'] . "</th>";
                echo "<th>" . $rij['klantAdres'] . "</th>";
                echo "<th> <a href='klant_detail.php?id=". $rij['klantID']."'>detail</a></th>";
                echo "</tr>";
            }
            echo "</tbody>";
            echo "</table>";
            }

            ?>
    </div>

    </div>

    <?php
    require 'PHP/foot.php';
    ?>

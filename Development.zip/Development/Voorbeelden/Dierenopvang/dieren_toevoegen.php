<?php
$page = "newUser";
require 'PHP/config.php';
require 'PHP/head.php';
require 'PHP/sessionCheck.php';
?>
<?php

?>
<div class="container">
    <div class="formBox2">
        <div class="card2">
            <h2>Dieren Form</h2>
            <form class="px-4 py-3" action="PHP/dieren_toevoegen_verwerken.php" method="post" enctype="multipart/form-data">

                <div class="row mb-3">
                    <label for="Soort" class="col-sm-2 col-form-label">Soort: </label>
                    <div class="col-sm-10">
                        <input type="text" name="Soort" class="form-control" id="Soort" placeholder="Hond" required>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="Naam" class="col-sm-2 col-form-label">Naam: </label>
                    <div class="col-sm-10">
                        <input type="text" name="Naam" class="form-control" id="Naam" placeholder="Snowbal" required>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="Ras" class="col-sm-2 col-form-label">Ras: </label>
                    <div class="col-sm-10">
                        <input type="text" name="Ras" class="form-control" id="Ras" placeholder="mix" required>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="Kleur" class="col-sm-2 col-form-label">Kleur: </label>
                    <div class="col-sm-10">
                        <input type="text" name="Kleur" class="form-control" id="Kleur" placeholder="blond" required>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="Geboortedatum" class="col-sm-2 col-form-label">Geboortedatum: </label>
                    <div class="col-sm-10">
                        <input type="date" name="Geboortedatum" class="form-control" id="Geboortedatum" placeholder="01-Jan-2000" required>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="DatumBinnen" class="col-sm-2 col-form-label">DatumBinnen: </label>
                    <div class="col-sm-10">
                        <input type="date" name="DatumBinnen" class="form-control" id="DatumBinnen" placeholder="29-Feb-2010" required>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="Geslacht" class="col-sm-2 col-form-label">Geslacht: </label>
                    <div class="col-sm-10">
                        <select name="Geslacht" id="Geslacht" class="form-select">
                            <option selected disabled>Selecteer Geslacht</option>
                            <option value="Vrouw">Vrouw</option>
                            <option value="Man">Man</option>
                        </select>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="Gecastreert" class="col-sm-2 col-form-label">Gecastreert: </label>
                    <div class="col-sm-10">
                        <select name="Gecastreert" id="Gecastreert" class="form-select">
                            <option selected disabled>Selecteer Gecastreert</option>
                            <option value="nee">Nee</option>
                            <option value="ja">Ja</option>
                        </select>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="Geent" class="col-sm-2 col-form-label">Ingeënt:</label>
                    <div class="col-sm-10">
                        <select name="Geent" id="Geent" class="form-select">
                            <option selected disabled>Selecteer</option>
                            <option value="ja">Ja</option>
                            <option value="nee">Nee</option>
                        </select>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="Status" class="col-sm-2 col-form-label">Status:</label>
                    <div class="col-sm-10">
                        <select name="Status" id="Status" class="form-select">
                            <option selected disabled>Selecteer Status</option>
                            <option value="opvang">In opvang</option>
                            <option value="dood">Dood</option>
                            <option value="opgehaald">opgehaald</option>
                        </select>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="image" class="col-sm-2 col-form-label" >Foto</label>
                    <div class="col-sm-10">
                        <input type="file" name="file" class="form-control" id="image" />
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="Medische" class="col-sm-2 col-form-label">Medische Gegevens: </label>
                    <div class="col-sm-10">
                        <textarea name="Medische" class="form-control" id="Medische" placeholder="Medische Gegevens" required></textarea>
                    </div>
                </div>
                <div class="row mb-3">
                    <label for="Omschrijving" class="col-sm-2 col-form-label">Omschrijving: </label>
                    <div class="col-sm-10">
                        <textarea name="Omschrijving" class="form-control" id="Omschrijving" placeholder="Omschrijving" required></textarea>
                    </div>
                </div>

                <button type="submit" class="btn dtButton btn-primary">Toevoegen</button>
            </form>
        </div>
    </div>
</div>


<?php
require 'PHP/foot.php';
?>

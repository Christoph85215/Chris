<?php
$page = "Klant Details";
require 'PHP/config.php';
require 'PHP/head.php';
require 'PHP/sessionCheck.php';

$id = $_GET['id'];

$query = "SELECT * FROM `Klanten` WHERE klantID = '".$id."'";
$resultaat = mysqli_query($verbinding, $query);
$rij = mysqli_fetch_array($resultaat);

$klantID = $rij['klantID'];

$query2 = "SELECT * FROM `facture` WHERE klantID = '".$klantID."'";
$resultaat2 = mysqli_query($verbinding, $query2);
$row = mysqli_fetch_array($resultaat2);



?>


<div class="container">
    <div class="klantDetail">
        <img class="userFoto" src="IPP/user.png">
        <?php
        if (empty($row['factuurID'])){
            ?>
            <p class="geenPDF"><strong>Er is geen PDF</strong></p>
        <?php
        }else{
            ?>
        <button class="PDF"><a href="facture.php?t_id=<?php echo $id?>">PDF</a></button>
        <?php
        }
        ?>
        <ul class="info1">
            <li>Naam: <?php echo $rij['klantVoornaam']?></li>
            <li>Telefone: <?php echo $rij['klantTelefoon']?></li>
            <li>Adres: <?php echo $rij['klantAdres']?></li>
            <li>E-mail: <?php echo $rij['klantEmail']?></li>
        </ul>
        <ul class="info2">
            <li>Achretnaam: <?php echo $rij['klantAchternaam']?></li>
            <li>Stad: <?php echo $rij['klantStad']?></li>
        </ul>
        <ul class="info3">
            <li>Document Nummer(id):<?php echo $rij['klantID'];?>
            </li>
        </ul>
    </div>
</div>


<?php
require 'PHP/foot.php';
?>

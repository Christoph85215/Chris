<?php
$page = "Dieren";
require 'PHP/config.php';
require 'PHP/head.php';
require 'PHP/sessionCheck.php';
?>



<?php
//Maak de query
$query = "SELECT * FROM dieren";

//Vang het resultaat van de query op in 'resultaat'
$resultaat = mysqli_query($verbinding, $query);

//Als het resultaat uit 0 rijen bestaat:
if (mysqli_num_rows($resultaat) == 0)
{
    echo "<p>Er zijn geen resultaten gevonden.</p>";
}
//Als er wel rijen zijn gevonden:
else{
    //Maak een tabel (BUITEN DE WHILE_LUS!)


    ?>
    <table style='width: 800px' class='table dieren table-striped table-dark'>
        <thead>
            <tr>
                <th scope='col'>Foto</th>
                <th scope='col'>Dier Soort</th>
                <th scope='col'>Ras</th>
                <th scope='col'>Detail</th>
            </tr>
        </thead>

        <tbody>
    <?php
    //Via een while worden alle rijen uitgelezen en getoond
    while ($rij = mysqli_fetch_array($resultaat))
    {
        echo "<tr>";
        echo "<th scope='row'><img src='" . $rij['foto'] . "' width='100' height='65'></td>";
        echo "<th>" . $rij['dierSoort'] . "</th>";
        echo "<th>" . $rij['ras'] . "</th>";
        echo "<th> <a href='dieren_detail.php?id=".$rij['dierID']."'>detail</a></th>";
        echo "</tr>";
    }
        echo "</tbody>";
    echo "</table>";
}

?>


<?php
require 'PHP/foot.php';
?>

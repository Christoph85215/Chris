<?php
$page = "newUser";
require 'PHP/config.php';
require 'PHP/head.php';
?>
<?php

?>
<div class="container">
    <div class="formBox">
        <div class="card">
            <form class="px-4 py-3" action="PHP/newKlantVerwerk.php" method="post">
                <div class="form-group">
                    <label for="newklantVoornaam">Voornaam</label>
                    <input type="text" name="newklantVoornaam" class="form-control" id="newklantVoornaam" placeholder="Piet" required>
                </div>
                <div class="form-group">
                    <label for="newklantAchternaam">Achternaam</label>
                    <input type="text" name="newklantAchternaam" class="form-control" id="newklantAchternaam" placeholder="De Jong" required>
                </div>
                <div class="form-group">
                    <label for="newklantAdres">Straat + huisnr</label>
                    <input type="text" name="newklantAdres" class="form-control" id="newklantAdres" placeholder="KoningStraat 23" required>
                </div>
                <div class="form-group">
                    <label for="newklantStad">Stad</label>
                    <input type="text" name="newklantStad" class="form-control" id="newklantStad" placeholder="Den Haag" required>
                </div>
                <div class="form-group">
                    <label for="newklantTelefoon">Telefoon</label>
                    <input type="text" name="newklantTelefoon" class="form-control" id="newklantTelefoon" placeholder="061234567890" required>
                </div>
                <div class="form-group">
                    <label for="newklantEmail">Email adres</label>
                    <input type="text" name="newklantEmail" class="form-control" id="newklantEmail" placeholder="piet@dejong.nl" required>
                </div>
                <div class="form-group">
                    <label for="newklantDocnr">Docnr</label>
                    <input type="text" name="newklantDocnr" class="form-control" id="newklantDocnr" placeholder="8sdfgsd78jh" required>
                </div>
                <button type="submit" class="btn btn-primary">Toevoegen</button>
            </form>
        </div>
    </div>

</div>

<?php
require 'PHP/foot.php';
?>

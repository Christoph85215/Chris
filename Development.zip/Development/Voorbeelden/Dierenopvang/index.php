<?php
$page = "Login";
require 'PHP/config.php';
require 'PHP/head.php';
?>

<div class="container">
    <div class="loginBox">
        <div class="col-sm-8 col-md-5 col-lg-5 col-xl-3 col-12 mx-auto">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Login</h5>
                    <form class="px-4 py-3" method="post">
                        <div class="form-group">
<!--                            <label for="userEmail">Email adres</label>-->
                            <div class="input-group mb-3">
                                <span class="input-group-text" id="basic-addon1"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-person-fill" viewBox="0 0 16 16">
                                <path d="M3 14s-1 0-1-1 1-4 6-4 6 3 6 4-1 1-1 1H3zm5-6a3 3 0 1 0 0-6 3 3 0 0 0 0 6z"/></svg></span>
                                <input type="email" name="userEmail" class="form-control" id="userEmail" placeholder="email@voorbeeld.com">
                            </div>
                        </div>
                        <div class="form-group">
<!--                            <label for="password">Wachtwoord</label>-->
                            <div class="input-group mb-3">
                                <span class="input-group-text" id="basic-addon1"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-key-fill" viewBox="0 0 16 16">
                                <path d="M3.5 11.5a3.5 3.5 0 1 1 3.163-5H14L15.5 8 14 9.5l-1-1-1 1-1-1-1 1-1-1-1 1H6.663a3.5 3.5 0 0 1-3.163 2zM2.5 9a1 1 0 1 0 0-2 1 1 0 0 0 0 2z"/></svg></span>
                                <input type="password" name="password" class="form-control" id="password" placeholder="Wachtwoord">
                            </div>
                        </div>
                        <button type="submit" name="submit" class="btn btn-primary">Login</button>
                    </form>
                </div>

                <?php
                
                if (isset($_POST['submit']))
                {


                    $email = $_POST['userEmail'];
                    $password = md5($_POST['password']);

                    $query = "SELECT * FROM medewerkers WHERE email = '$email' AND password = '$password'";

                    $resultaat = mysqli_query($verbinding, $query);

                    if (mysqli_num_rows($resultaat) > 0)
                    {
                        //echo "<p>$Gebruikersnaam, u bent ingelogd!</p>";
                        $user = mysqli_fetch_array($resultaat);

                        $_SESSION['ID'] = $user['medewerkerID'];
                        $_SESSION['email'] = $user['email'];
                        $_SESSION['role'] = $user['role'];
                        ?>
                        <div class="alert alert-success" role="alert">
                            <p>Je bent ingelogd.</p><br>
                            <p><?= $_SESSION['email'] ?></p>
                            <button id="ButtonDG" class="btn btn-primary"><a href="dieren.php">Door Gaan</a></button>
                        </div>
                        <?php
                        header("location: dieren.php");
                    }
                    else
                    {
                        ?>
                        <div class="alert alert-warning" role="alert">
                            <p>Email en/of wachtwoord is niet goed.</p>
                            <p>Probeer nogmaals.</p>
                        </div>
                        <?php
                    }
                }
                ?>
            </div>
        </div>
    </div>

</div>
<?php
require 'PHP/foot.php';
?>
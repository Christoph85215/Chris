<?php
$page = "newUser";
require 'PHP/config.php';
require 'PHP/head.php';
?>
<?php

?>
<div class="container">
    <div class="formBox">
        <div class="card">
            <form class="px-4 py-3" action="PHP/newUserVerwerk.php" method="post">
                <div class="form-group">
                    <label for="newuserEmail">Email-adres</label>
                    <input type="email" name="newuserEmail" class="form-control" id="newuserEmail" placeholder="piet@dejong.com" required>
                </div>
                <div class="form-group">
                    <label for="newuserVoornaam">Voornaam</label>
                    <input type="text" name="newuserVoornaam" class="form-control" id="newuserVoornaam" placeholder="Piet" required>
                </div>
                <div class="form-group">
                    <label for="newuserAchternaam">Achternaam</label>
                    <input type="text" name="newuserAchternaam" class="form-control" id="newuserAchternaam" placeholder="De Jong" required>
                </div>
                <div class="form-group">
                    <label for="newuserGebruikersnaam">Gebruikersnaam</label>
                    <input type="text" name="newuserGebruikersnaam" class="form-control" id="newuserGebruikersnaam" placeholder="PDJong" required>
                    <div id="emailHelp" class="form-text">Inicialen in hoofdletters, met achternaam aanvast.</div>
                </div>
                <div class="form-group">
                    <label for="newuserWachtwoord">Wachtwoord</label>
                    <input type="password" name="newuserWachtwoord" class="form-control" id="newuserWachtwoord" placeholder="Password" required>
                </div>
                <button type="submit" class="btn btn-primary">Aanmaken</button>
            </form>
            <div class="dropdown-divider"></div>
            <a class="dropdown-item" href="login.php">Already an acount? Login</a>
        </div>
    </div>

</div>

<?php
require 'PHP/foot.php';
?>
